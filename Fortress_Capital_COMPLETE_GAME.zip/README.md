# FORTRESS CAPITAL, COMPLETE GAME BUILD

This ZIP contains a self-contained, playable game plus the intended React/FastAPI/LangGraph integration structure.

## Fastest demo

Open `game/index.html` directly in a browser.

No npm, Python, database, API key or internet connection is required for the game showcase.

## React mode

```bash
cd react-app
npm install
npm run dev
```

The React app hosts the same game.

## Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

The backend is an integration seam for the LangGraph Game Master. The current game intentionally runs standalone so judges can play instantly.

## What the game actually contains

- 5 difficulty levels
- 25 scenario library, 5 per difficulty tier
- Scenario briefing before every run
- 90-second timed boss fight
- 5 AI agents
- Active agent abilities
- 3 strategic decisions with different risk/reward profiles
- 2 market curveballs per run
- Rival bank, Titan Capital
- Animated fortress/capital-markets world
- Live district power levels
- Crisis escalation
- Combo multiplier
- Score calculation
- Win/loss conditions
- Replay loop
- Sound effects generated with WebAudio
- Responsive layout
- No external game engine required

## Intended hackathon architecture

React game UI
→ FastAPI
→ LangGraph Game Master
→ specialist agents
→ shared in-memory state
→ market/event tool calls
→ WebSocket/SSE event stream
→ React animation/event layer

The game should remain game-first. AI reasoning should manifest through agent actions, dialogue, alerts, market events and visual state changes, not a dashboard full of text.
