import React from 'react';
import {createRoot} from 'react-dom/client';
import '../style.css';
const Game=()=> <iframe title="Fortress Capital" src="/game/index.html" style={{width:'100vw',height:'100vh',border:0}}/>;
createRoot(document.getElementById('root')).render(<Game/>);
