"""
LangGraph adapter seam for Fortress Capital.

Recommended graph:
START
  -> MarketObserver
  -> ScenarioOracle
  -> [RiskWarden, MarketPilot, DealCaptain, DarkIntel, Treasury]
  -> SwarmDebate
  -> GameMaster
  -> EventEngine
  -> END

Keep state structured so React can render agent actions rather than raw model text.
"""

def build_graph():
    # Import and construct the actual StateGraph here when connected to
    # the model/provider used by the hackathon.
    return None
