from fastapi import FastAPI
from pydantic import BaseModel
from typing import Dict, Any
import random

app = FastAPI(title="Fortress Capital Game Master")

class GameState(BaseModel):
    difficulty: str = "INTERMEDIATE"
    scenario: str = "The Perfect Storm"
    state: Dict[str, Any] = {}

@app.get("/health")
def health():
    return {"status":"online","service":"fortress-capital-game-master"}

@app.post("/agent/decide")
def decide(game: GameState):
    # Replace this deterministic seam with a LangGraph swarm in the hackathon.
    # Each specialist agent can return a structured action, rationale and confidence.
    crisis = float(game.state.get("crisis",40))
    if crisis > 70:
        action = "fortify"
    elif float(game.state.get("client",74)) < 50:
        action = "save"
    else:
        action = random.choice(["investigate","fortify","save"])
    return {"agent":"game_master","action":action,"confidence":0.82}
