# FORTRESS CAPITAL 2.0 — GAME SHOWCASE BUILD

This package is the visual/game-first prototype for the Fortress Capital hackathon game.

## Run

```bash
cd frontend
npm install
npm run dev
```

Then open the Vite URL, normally http://localhost:5173.

## What is inside

- Image-backed cinematic title screen
- Original Fortress Capital key art in `frontend/public/assets/`
- Reusable SVG game assets
- 90-second boss-fight loop
- Five AI agents with active abilities
- Three strategic commands
- Two triggerable curveballs
- Rival bank attack
- Living fortress with five capital-markets districts
- Resource meters and crisis state
- Swarm feed and agent dialogue
- Combo scoring
- Victory / defeat cinematic
- Responsive React implementation

## Architecture for hackathon integration

The current showcase is deliberately self-contained so judges can play it without a backend. The next integration point is to replace the deterministic `applyDecision()` and `agentAbility()` logic in `src/main.jsx` with FastAPI/LangGraph calls.

Recommended runtime:

React game client
→ FastAPI game API
→ LangGraph Game Master
→ specialist agents
→ shared in-memory world state
→ event/curveball engine
→ React WebSocket/SSE updates

The UI should remain game-first. AI output should manifest as characters moving, arguing, discovering threats and executing abilities, rather than appearing as a dashboard of model responses.
