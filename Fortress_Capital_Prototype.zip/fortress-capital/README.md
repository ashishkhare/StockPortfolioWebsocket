# Fortress Capital

A hackathon-ready prototype for **Fortress Capital: Capital in Peril**.

## What is included

- React + Vite frontend
- FastAPI backend
- In-memory game state
- Difficulty selection: Novice, Beginner, Intermediate, Advanced, Master
- 25 scenario library entries, 5 per difficulty
- 90-second Showcase, 5-minute Quick Crisis, 20-minute Full Command
- Stylized block/low-poly-inspired fortress UI using CSS, no external game assets
- AI swarm panel with Banker, Syndicate, Trader, Risk, Treasury, Compliance and Intelligence agents
- Agent consensus/conflict
- Curveballs
- Capital, liquidity, reputation, client confidence and regulatory health
- Fortress integrity and crisis meter
- XP, achievements, combo chains and post-game report
- Backend endpoints for starting games, making decisions, triggering curveballs and scoring

## Run

### Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Open the URL printed by Vite.

## Architecture

The prototype keeps the game engine deterministic and local, with a clear seam for replacing the scenario/agent logic with LangGraph.

Suggested production architecture:

React -> FastAPI -> LangGraph Game Master
                         |
                         +-- Scenario Agent
                         +-- Market Agent
                         +-- Risk Agent
                         +-- Treasury Agent
                         +-- Syndicate Agent
                         +-- Compliance Agent
                         +-- Intelligence Agent
                         +-- Competitor Agent

Real-time market/news tools can be connected inside the Game Master later.
