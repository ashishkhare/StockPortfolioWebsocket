from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from uuid import uuid4
from datetime import datetime
import random, time

app = FastAPI(title="Fortress Capital Game API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"]
)

SCENARIOS = {
"NOVICE":[
 {"id":"N1","title":"The Weakening IPO","brief":"Investor demand is falling on your flagship $4B IPO. Save the book without damaging the fortress.","threat":"IPO DEMAND","type":"ipo"},
 {"id":"N2","title":"Treasury Under Pressure","brief":"Settlement requirements have created a sudden liquidity squeeze. Capital exists, but cash is tight.","threat":"LIQUIDITY","type":"liquidity"},
 {"id":"N3","title":"Save the Block","brief":"A $2B institutional block is ready, but market volatility is rising by the minute.","threat":"EXECUTION","type":"block"},
 {"id":"N4","title":"The Wall Cross","brief":"A major investor wants early access to confidential IPO information. Compliance has concerns.","threat":"MNPI","type":"compliance"},
 {"id":"N5","title":"Build the Fortress","brief":"Allocate $5B across your core capabilities before the first market shock arrives.","threat":"CAPITAL ALLOCATION","type":"build"}
],
"BEGINNER":[
 {"id":"B1","title":"Competitor Invasion","brief":"A rival bank is attacking your flagship client with a fee-cutting offer.","threat":"COMPETITOR","type":"competitor"},
 {"id":"B2","title":"Market Storm","brief":"Three transactions are live as volatility surges across the market.","threat":"VOLATILITY","type":"market"},
 {"id":"B3","title":"The Whale","brief":"A sovereign wealth fund offers $1B of cornerstone demand, but wants a huge allocation.","threat":"CONCENTRATION","type":"whale"},
 {"id":"B4","title":"The Leak","brief":"Confidential transaction information has escaped. Find the source before the second leak.","threat":"MNPI LEAK","type":"leak"},
 {"id":"B5","title":"Save the Subsidiary","brief":"The parent bank is reviewing your franchise. Prove that the subsidiary deserves more capital.","threat":"PARENT REVIEW","type":"subsidiary"}
],
"INTERMEDIATE":[
 {"id":"I1","title":"The Perfect Storm","brief":"IPO demand, market conditions and liquidity are deteriorating at the same time.","threat":"MULTI-CRISIS","type":"storm"},
 {"id":"I2","title":"IPO or Die","brief":"Your flagship IPO represents 35% of annual franchise revenue. The swarm is deeply divided.","threat":"DEAL CONCENTRATION","type":"ipo"},
 {"id":"I3","title":"Contagion","brief":"A shock in Tokyo is spreading through Hong Kong and India, with London now showing stress.","threat":"GLOBAL CONTAGION","type":"contagion"},
 {"id":"I4","title":"The Regulatory Trap","brief":"A highly profitable transaction may contain an MNPI issue. The book is closing fast.","threat":"REGULATORY","type":"regulatory"},
 {"id":"I5","title":"Fortress Rebuild","brief":"Rebuild a damaged franchise while a market recovery creates a tempting growth opportunity.","threat":"REBUILD","type":"rebuild"}
],
"ADVANCED":[
 {"id":"A1","title":"Black Swan","brief":"Something is wrong. No single agent has the complete picture. Discover the hidden crisis.","threat":"UNKNOWN","type":"blackswan"},
 {"id":"A2","title":"The Saboteur","brief":"One agent is operating on corrupted information. Identify the bad signal before acting.","threat":"TRUST","type":"saboteur"},
 {"id":"A3","title":"Five-City Crisis","brief":"Mumbai, Hong Kong, Tokyo, London and New York all need rescue capital.","threat":"GLOBAL CAPITAL","type":"fivecity"},
 {"id":"A4","title":"Bank Wars","brief":"A competitor AI is actively reacting to your strategy and trying to steal your mandates.","threat":"AI COMPETITOR","type":"bankwars"},
 {"id":"A5","title":"The Board Coup","brief":"The Board wants proof of strategic value. Growth, defense, restructuring and exit are all on the table.","threat":"BOARD","type":"board"}
],
"MASTER":[
 {"id":"M1","title":"Doomsday","brief":"Five crisis vectors have been selected by the Game Master. You will discover them as they unfold.","threat":"BLACK SWAN","type":"doomsday"},
 {"id":"M2","title":"Swarm Civil War","brief":"Your agents have split into commercial and defense factions. You must resolve the conflict.","threat":"AGENT FACTIONS","type":"civilwar"},
 {"id":"M3","title":"Global Meltdown","brief":"Five markets are deteriorating simultaneously. Saving one fortress can doom another.","threat":"GLOBAL MELTDOWN","type":"meltdown"},
 {"id":"M4","title":"The Last Deal","brief":"A $10B global M&A transaction could save the subsidiary, but every dependency is under attack.","threat":"LAST DEAL","type":"lastdeal"},
 {"id":"M5","title":"The Fall of Fortress Capital","brief":"Everything starts badly. A hidden recovery path exists, but the swarm must discover it.","threat":"TOTAL CRISIS","type":"fall"}
]}

DECISIONS = [
 {"id":"fortify","title":"Fortify Liquidity","description":"Move capital into Treasury and protect the fortress against the next shock.","icon":"🛡️","risk":"Low","reward":"Stability"},
 {"id":"save_deal","title":"Save the Deal","description":"Deploy commercial firepower to protect the active transaction and client.","icon":"💰","risk":"Medium","reward":"Revenue"},
 {"id":"hedge","title":"Hedge the Market","description":"Reduce market exposure before the next volatility wave hits.","icon":"📈","risk":"Low","reward":"Protection"},
 {"id":"investigate","title":"Deploy Intelligence","description":"Ask the swarm to investigate hidden signals and challenge conflicting recommendations.","icon":"🧠","risk":"Low","reward":"Information"},
 {"id":"push","title":"Push the Transaction","description":"Take the aggressive route and capture maximum economics while the window is open.","icon":"⚡","risk":"High","reward":"Profit"},
 {"id":"compliance","title":"Call Compliance","description":"Pause the transaction and establish a clean regulatory path.","icon":"⚖️","risk":"Low","reward":"Regulatory"}
]

class StartRequest(BaseModel):
    difficulty: str
    mode: str
    scenario_id: str | None = None

class DecisionRequest(BaseModel):
    decision_id: str

games = {}

def difficulty_config(d):
    return {
        "NOVICE": {"crisis":22,"consensus":88,"curveballs":2,"reliability":94},
        "BEGINNER": {"crisis":32,"consensus":78,"curveballs":3,"reliability":88},
        "INTERMEDIATE": {"crisis":45,"consensus":68,"curveballs":4,"reliability":80},
        "ADVANCED": {"crisis":58,"consensus":54,"curveballs":6,"reliability":72},
        "MASTER": {"crisis":68,"consensus":42,"curveballs":8,"reliability":62}
    }[d]

def duration(mode):
    return {"SHOWCASE":90,"QUICK":300,"FULL":1200}.get(mode,300)

def make_agents(cfg, typ):
    base = {}
    messages = {
      "banker":"Protect the client and economics.",
      "syndicate":"Book quality is deteriorating.",
      "trader":"Market liquidity is becoming fragile.",
      "risk":"Capital preservation is the priority.",
      "treasury":"Liquidity buffer needs attention.",
      "compliance":"No immediate breach, monitoring closely.",
      "intelligence":"I am looking for a second-order signal."
    }
    for i,a in enumerate(["banker","syndicate","trader","risk","treasury","compliance","intelligence"]):
        c=max(42,min(99,cfg["reliability"]+random.randint(-8,8)))
        status="stable"
        if typ in ("storm","doomsday","civilwar","fall") and a in ("risk","treasury"):
            status="warning"
        if typ in ("regulatory","compliance","leak") and a=="compliance":
            status="warning"
        base[a]={"confidence":c,"message":messages[a],"status":status}
    if typ in ("saboteur","blackswan","doomsday","fall"):
        victim=random.choice(list(base))
        base[victim]["confidence"]=random.randint(45,67)
        base[victim]["status"]="conflict"
        base[victim]["message"]="Signal confidence is unusually low. Challenge me."
    return base

def metrics_for(d):
    if d=="NOVICE": return {"capital":88,"liquidity":85,"reputation":90,"client":90,"regulatory":96}
    if d=="BEGINNER": return {"capital":82,"liquidity":76,"reputation":84,"client":82,"regulatory":92}
    if d=="INTERMEDIATE": return {"capital":70,"liquidity":62,"reputation":76,"client":76,"regulatory":88}
    if d=="ADVANCED": return {"capital":55,"liquidity":48,"reputation":61,"client":64,"regulatory":76}
    return {"capital":40,"liquidity":35,"reputation":45,"client":52,"regulatory":70}

def integrity(m):
    return round(sum(m.values())/len(m))

def market_label(crisis):
    if crisis<30:return "-0.8%"
    if crisis<50:return "-2.1%"
    if crisis<70:return "-3.8%"
    return "-6.4%"

def serialize(g):
    return {
      "game_id":g["id"],"difficulty":g["difficulty"],"mode":g["mode"],
      "scenario":g["scenario"],"metrics":g["metrics"],"integrity":integrity(g["metrics"]),
      "crisis":g["crisis"],"consensus":g["consensus"],"agents":g["agents"],
      "decisions":DECISIONS[:3] if g["turn"]<2 else DECISIONS[2:5],
      "remaining_seconds":max(0,int(g["end_at"]-time.time())),
      "curveball_count":g["curveballs"],"max_curveballs":g["max_curveballs"],
      "combo":g["combo"],"market_label":market_label(g["crisis"]),
      "event":g.get("event"),"finished":g["finished"],
      "score":g.get("score"),"result":g.get("result"),"result_message":g.get("result_message"),
      "report":g.get("report",{}),"xp_earned":g.get("xp_earned",0),
      "achievement":g.get("achievement",""),"insight":g.get("insight",""),
      "insight_detail":g.get("insight_detail","")
    }

@app.get("/health")
def health(): return {"status":"ok","service":"fortress-capital"}

@app.post("/game/start")
def start(req: StartRequest):
    d=req.difficulty.upper()
    if d not in SCENARIOS: raise HTTPException(400,"Unknown difficulty")
    pool=SCENARIOS[d]
    scenario=next((s for s in pool if s["id"]==req.scenario_id),None) if req.scenario_id else random.choice(pool)
    if not scenario: scenario=random.choice(pool)
    cfg=difficulty_config(d)
    gid=str(uuid4())
    g={
      "id":gid,"difficulty":d,"mode":req.mode,"scenario":scenario,
      "metrics":metrics_for(d),"crisis":cfg["crisis"],"consensus":cfg["consensus"],
      "agents":make_agents(cfg,scenario["type"]),"curveballs":0,"max_curveballs":cfg["curveballs"],
      "combo":0,"turn":0,"finished":False,"start_at":time.time(),"end_at":time.time()+duration(req.mode),
      "event":{"title":"CRISIS DETECTED","message":scenario["brief"]}
    }
    games[gid]=g
    return serialize(g)

def apply_decision(g, decision_id):
    m=g["metrics"]
    typ=g["scenario"]["type"]
    delta={"capital":0,"liquidity":0,"reputation":0,"client":0,"regulatory":0}
    if decision_id=="fortify":
        delta.update(capital=-4,liquidity=13,reputation=1,client=-1)
    elif decision_id=="save_deal":
        delta.update(capital=-7,liquidity=-3,reputation=7,client=10)
        if typ in ("ipo","whale","lastdeal"): delta["reputation"]+=4
    elif decision_id=="hedge":
        delta.update(capital=-5,liquidity=4,reputation=0,client=-2)
        g["crisis"]-=13
    elif decision_id=="investigate":
        delta.update(capital=-1,liquidity=-1,reputation=2,client=1,regulatory=3)
        g["consensus"]+=8
        if typ in ("leak","saboteur","blackswan","doomsday","fall"): g["crisis"]-=12
    elif decision_id=="push":
        delta.update(capital=-9,liquidity=-7,reputation=6,client=9,regulatory=-5)
        g["crisis"]+=6
    elif decision_id=="compliance":
        delta.update(capital=-2,liquidity=-2,reputation=-1,client=-4,regulatory=12)
        g["crisis"]-=4
    for k,v in delta.items(): m[k]=max(0,min(100,m[k]+v))
    g["crisis"]=max(0,min(100,g["crisis"]+random.randint(-4,7)))
    g["consensus"]=max(20,min(99,g["consensus"]+random.randint(-5,5)))
    g["turn"]+=1
    g["combo"] += 1 if decision_id in ("investigate","fortify","hedge") else 2
    if g["turn"] in (2,4,6) and g["curveballs"]<g["max_curveballs"]:
        trigger_curveball_internal(g)

def trigger_curveball_internal(g):
    g["curveballs"]+=1
    events=[
      ("COMPETITOR ATTACK","A rival bank has launched a client-poaching offer.",{"reputation":-7,"client":-9}),
      ("INVESTOR WITHDRAWAL","A large investor has pulled $300M from the book.",{"liquidity":-8,"client":-5}),
      ("FLASH CRASH","The market drops another 2.4% in seconds.",{"capital":-5,"liquidity":-5}),
      ("REGULATOR ALERT","Compliance receives an urgent information request.",{"regulatory":-8,"reputation":-2}),
      ("FUNDING SHOCK","Funding costs have jumped unexpectedly.",{"liquidity":-10,"capital":-3}),
      ("UNKNOWN SIGNAL","Intelligence detects a second-order risk nobody has modeled.",{"crisis":8,"consensus":-10})
    ]
    title,msg,changes=random.choice(events)
    for k,v in changes.items():
        if k=="crisis": g["crisis"]=max(0,min(100,g["crisis"]+v))
        elif k in g["metrics"]: g["metrics"][k]=max(0,min(100,g["metrics"][k]+v))
    g["event"]={"title":title,"message":msg}
    return g["event"]

def finish(g):
    integ=integrity(g["metrics"])
    if integ>=85: result="LEGENDARY"
    elif integ>=62: result="VICTORY"
    elif integ>=42: result="PYRRHIC"
    else: result="DEFEAT"
    score=max(0,min(1000,round(integ*7 + g["combo"]*18 + g["consensus"]*1.2)))
    if result=="LEGENDARY": msg="The fortress absorbed the shock and emerged stronger."
    elif result=="VICTORY": msg="You protected the franchise and made the critical calls."
    elif result=="PYRRHIC": msg="You survived, but the fortress paid a heavy price."
    else: msg="The fortress fell. Your post-mortem reveals where the swarm broke down."
    g.update({
      "finished":True,"score":score,"result":result,"result_message":msg,
      "xp_earned":120+(score//4),"achievement":("FORTRESS LEGEND" if result=="LEGENDARY" else "CRISIS SURVIVOR" if result!="DEFEAT" else "AGAINST ALL ODDS"),
      "insight":"You balanced survival and opportunity under pressure.",
      "insight_detail":"The strongest commanders do not simply follow the swarm. They understand disagreement, preserve optionality and spend capital where it changes the outcome.",
      "report":{
        "financial":max(20,min(99,round(g["metrics"]["capital"]*.72+g["metrics"]["client"]*.28))),
        "swarm":max(20,min(99,round(g["consensus"]+random.randint(-4,6)))),
        "decision":max(20,min(99,round((g["metrics"]["reputation"]+g["metrics"]["client"])/2))),
        "risk":max(20,min(99,round((g["metrics"]["liquidity"]+g["metrics"]["regulatory"])/2)))
      }
    })

@app.get("/game/{gid}")
def get_game(gid:str):
    g=games.get(gid)
    if not g: raise HTTPException(404,"Game not found")
    if not g["finished"] and time.time()>=g["end_at"]: finish(g)
    return serialize(g)

@app.post("/game/{gid}/decision")
def make_decision(gid:str, req:DecisionRequest):
    g=games.get(gid)
    if not g: raise HTTPException(404,"Game not found")
    if g["finished"]: return serialize(g)
    if time.time()>=g["end_at"]:
        finish(g); return serialize(g)
    apply_decision(g,req.decision_id)
    if integrity(g["metrics"])<18 or g["turn"]>=8:
        finish(g)
    return serialize(g)

@app.post("/game/{gid}/curveball")
def curveball(gid:str):
    g=games.get(gid)
    if not g: raise HTTPException(404,"Game not found")
    if g["finished"]: return serialize(g)
    trigger_curveball_internal(g)
    if integrity(g["metrics"])<18: finish(g)
    return serialize(g)
