"""
LangGraph seam for production integration.

Replace the deterministic make_agents/apply_decision flow with a StateGraph.

Suggested nodes:
- scenario_generator
- market_intelligence
- banker_agent
- syndicate_agent
- trader_agent
- risk_agent
- treasury_agent
- compliance_agent
- intelligence_agent
- competitor_agent
- game_master
- scoring

The current FastAPI contract is intentionally simple so the React client
does not need to change when LangGraph is introduced.
"""
