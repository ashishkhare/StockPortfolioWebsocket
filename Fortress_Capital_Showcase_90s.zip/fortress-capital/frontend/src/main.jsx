import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Shield, Landmark, TrendingUp, Wallet, Scale, Brain, Users, Zap,
  AlertTriangle, Crosshair, Trophy, ChevronRight, RotateCcw, Activity,
  Clock3, Sparkles, Swords, Building2
} from "lucide-react";
import "./styles.css";

const API = "http://localhost:8000";

const difficulties = [
  {id:"NOVICE", label:"Novice", stars:1, tagline:"Learn to command", color:"#65d46e"},
  {id:"BEGINNER", label:"Beginner", stars:2, tagline:"Defend the fortress", color:"#8ed1ff"},
  {id:"INTERMEDIATE", label:"Intermediate", stars:3, tagline:"Capital under siege", color:"#ffd166"},
  {id:"ADVANCED", label:"Advanced", stars:4, tagline:"Fortress under siege", color:"#ff9f43"},
  {id:"MASTER", label:"Master", stars:5, tagline:"The fortress will fall", color:"#ff5c7a"}
];

const modes = [
  {id:"SHOWCASE", label:"Showcase", time:90, desc:"90 sec • judge-friendly"},
  {id:"QUICK", label:"Quick Crisis", time:300, desc:"5 min • full gameplay loop"},
  {id:"FULL", label:"Full Command", time:1200, desc:"20 min • complete simulation"}
];

const agents = [
  {id:"banker", name:"Banker", icon:Landmark, tone:"commercial"},
  {id:"syndicate", name:"Syndicate", icon:Users, tone:"commercial"},
  {id:"trader", name:"Trader", icon:TrendingUp, tone:"market"},
  {id:"risk", name:"Risk", icon:Shield, tone:"defense"},
  {id:"treasury", name:"Treasury", icon:Wallet, tone:"defense"},
  {id:"compliance", name:"Compliance", icon:Scale, tone:"defense"},
  {id:"intelligence", name:"Intelligence", icon:Brain, tone:"intel"}
];

function App(){
  const [screen,setScreen] = useState("home");
  const [difficulty,setDifficulty] = useState("INTERMEDIATE");
  const [mode,setMode] = useState("QUICK");
  const [game,setGame] = useState(null);
  const [busy,setBusy] = useState(false);
  const [toast,setToast] = useState(null);
  const [showcaseLocal,setShowcaseLocal] = useState(false);

  const showcaseGame = () => ({
    game_id:"SHOWCASE-DEMO", difficulty:"INTERMEDIATE", mode:"SHOWCASE",
    scenario:{id:"SHOWCASE",title:"THE PERFECT STORM",
      brief:"A $4B IPO is under pressure. Liquidity is tightening, a competitor is attacking the mandate and Compliance has detected an unusual signal.",
      threat:"MULTI-CRISIS"},
    metrics:{capital:70,liquidity:62,reputation:76,client:76,regulatory:88},
    integrity:74, crisis:48, consensus:71, combo:1, curveball_count:0, max_curveballs:2,
    remaining_seconds:90, market_label:"-3.8%", finished:false, turn:0,
    event:{title:"CRISIS DETECTED",message:"The swarm is online. You have 90 seconds to save the fortress."},
    decisions:[
      {id:"fortify",title:"Fortify Liquidity",description:"Move capital into Treasury and protect the fortress against the next shock.",icon:"🛡️",risk:"Low",reward:"Stability"},
      {id:"save_deal",title:"Save the IPO",description:"Deploy commercial firepower to protect the client and preserve the book.",icon:"💰",risk:"Medium",reward:"Revenue"},
      {id:"investigate",title:"Deploy Intelligence",description:"Challenge the swarm and expose hidden second-order risks.",icon:"🧠",risk:"Low",reward:"Information"}
    ],
    agents:{
      banker:{confidence:91,message:"Protect the client and economics.",status:"stable"},
      syndicate:{confidence:84,message:"Demand is weakening. Preserve book quality.",status:"stable"},
      trader:{confidence:72,message:"Liquidity is fragile. Volatility is rising.",status:"warning"},
      risk:{confidence:88,message:"Capital preservation is the priority.",status:"stable"},
      treasury:{confidence:79,message:"Liquidity buffer needs attention.",status:"warning"},
      compliance:{confidence:94,message:"Monitoring a potential MNPI issue.",status:"stable"},
      intelligence:{confidence:67,message:"I see a second-order signal. Investigate.",status:"conflict"}
    }
  });

  const localDecision = (id) => {
    setGame(prev => {
      if(!prev || prev.finished) return prev;
      const e = {
        fortify:{capital:-3,liquidity:13,reputation:2,client:-1,regulatory:1,crisis:-9,consensus:5},
        save_deal:{capital:-7,liquidity:-4,reputation:8,client:11,regulatory:-2,crisis:-5,consensus:2},
        investigate:{capital:-1,liquidity:-1,reputation:2,client:2,regulatory:4,crisis:-12,consensus:11}
      }[id] || {};
      const metrics={...prev.metrics};
      Object.keys(metrics).forEach(k=>metrics[k]=Math.max(0,Math.min(100,metrics[k]+(e[k]||0))));
      const msgs={
        fortify:["TREASURY FORTIFIED","Liquidity buffer restored. Risk agents are green."],
        save_deal:["IPO BOOK SAVED","Investor confidence recovered and the competitor attack was repelled."],
        investigate:["HIDDEN SIGNAL FOUND","Intelligence exposed a second-order risk. Swarm consensus is rising."]
      }[id];
      return {...prev,metrics,
        integrity:Math.round(Object.values(metrics).reduce((a,b)=>a+b,0)/5),
        crisis:Math.max(8,Math.min(100,prev.crisis+(e.crisis||0))),
        consensus:Math.max(30,Math.min(99,prev.consensus+(e.consensus||0))),
        combo:prev.combo+(id==="investigate"?2:1),turn:prev.turn+1,
        event:{title:msgs[0],message:msgs[1]},
        remaining_seconds:Math.max(0,prev.remaining_seconds-12)};
    });
    setToast("COMMAND EXECUTED");
    setTimeout(()=>setToast(null),1200);
  };

  const localCurveball = () => {
    setGame(prev=>{
      if(!prev || prev.finished || prev.curveball_count>=prev.max_curveballs) return prev;
      const metrics={...prev.metrics,liquidity:Math.max(0,prev.metrics.liquidity-8),client:Math.max(0,prev.metrics.client-6)};
      return {...prev,metrics,integrity:Math.round(Object.values(metrics).reduce((a,b)=>a+b,0)/5),
        crisis:Math.min(100,prev.crisis+12),curveball_count:prev.curveball_count+1,
        event:{title:"⚡ COMPETITOR ATTACK",message:"A rival bank has launched a fee-cutting offer against your IPO mandate."}};
    });
    setToast("CURVEBALL: COMPETITOR ATTACK");
    setTimeout(()=>setToast(null),1500);
  };

  const startGame = async (overrideScenario=null) => {
    setBusy(true);
    try {
      if(mode==="SHOWCASE" || overrideScenario==="N5"){
        setGame(showcaseGame());
        setShowcaseLocal(true);
        setScreen("game");
        setToast("SHOWCASE MODE ONLINE");
        setTimeout(()=>setToast(null),1600);
        return;
      }
      const r=await fetch(`${API}/game/start`,{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({difficulty,mode,scenario_id:overrideScenario})
      });
      const data=await r.json();
      setGame(data);setScreen("game");
    }catch(e){
      setToast("Backend unavailable. Showcase works without FastAPI.");
    }finally{setBusy(false);}
  };;

  const decision = async (id) => {
    if(showcaseLocal){ localDecision(id); return; }
    if(!game || game.finished) return;
    setBusy(true);
    try {
      const r = await fetch(`${API}/game/${game.game_id}/decision`, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({decision_id:id})
      });
      const data = await r.json();
      setGame(data);
      if(data.event) {
        setToast(data.event.title);
        setTimeout(()=>setToast(null),2500);
      }
      if(data.finished) setScreen("result");
    } finally { setBusy(false); }
  };

  const triggerCurveball = async () => {
    if(showcaseLocal){ localCurveball(); return; }
    if(!game || game.finished) return;
    const r = await fetch(`${API}/game/${game.game_id}/curveball`, {method:"POST"});
    const data = await r.json();
    setGame(data);
    setToast(data.event?.title || "Curveball detected");
    setTimeout(()=>setToast(null),2500);
    if(data.finished) setScreen("result");
  };

  useEffect(()=>{
    if(screen !== "game" || !game || game.finished || showcaseLocal) return;
    const t = setInterval(async ()=>{
      try {
        const r = await fetch(`${API}/game/${game.game_id}`);
        const data = await r.json();
        setGame(data);
        if(data.finished) setScreen("result");
      } catch {}
    },1000);
    return ()=>clearInterval(t);
  },[screen, game?.game_id, game?.finished]);

  if(screen==="home") return <Home difficulty={difficulty} setDifficulty={setDifficulty} mode={mode} setMode={setMode} startGame={startGame} busy={busy}/>;
  if(screen==="game") return <Game game={game} decision={decision} triggerCurveball={triggerCurveball} busy={busy} onQuit={()=>setScreen("home")}/>;
  return <Result game={game} onAgain={()=>startGame()} onHome={()=>setScreen("home")}/>;
}

function Shell({children}){ return <div className="app-shell">{children}</div>; }

function Home({difficulty,setDifficulty,mode,setMode,startGame,busy}){
  const d = difficulties.find(x=>x.id===difficulty);
  return <Shell>
    <div className="sky-glow"/>
    <header className="topbar">
      <div className="brand"><div className="brand-mark">FC</div><div><div className="brand-name">FORTRESS CAPITAL</div><div className="brand-sub">CAPITAL IN PERIL</div></div></div>
      <div className="top-chip"><Activity size={14}/> AI SWARM ONLINE</div>
    </header>

    <main className="landing">
      <section className="hero">
        <div className="eyebrow"><Swords size={16}/> THE MARKET IS UNDER ATTACK</div>
        <h1>BUILD. COMMAND.<br/><span>SURVIVE.</span></h1>
        <p>Command an AI investment-banking swarm through a market crisis. Every decision changes the fortress.</p>
        <div className="hero-actions">
          <button className="primary-cta" onClick={()=>startGame()} disabled={busy}><Zap size={18}/> ENTER FORTRESS <ChevronRight size={18}/></button>
          <button className="ghost-cta" onClick={()=>startGame("N5")} disabled={busy}><Sparkles size={17}/> SHOW ME THE MAGIC</button>
        </div>
      </section>

      <section className="fortress-preview">
        <FortressMap compact />
        <div className="preview-caption"><span>YOUR FORTRESS</span><b>ALL SYSTEMS AVAILABLE FROM THE START</b></div>
      </section>

      <section className="control-panel">
        <div className="panel-heading"><div><div className="eyebrow">01 / COMMAND SETUP</div><h2>Choose your battlefield</h2></div><div className="mini-stat"><Clock3 size={15}/> {modes.find(m=>m.id===mode).time<120? "90 SEC": modes.find(m=>m.id===mode).time<600 ? "5 MIN" : "20 MIN"}</div></div>
        <div className="mode-grid">
          {modes.map(m=><button key={m.id} className={`mode-card ${mode===m.id?"selected":""}`} onClick={()=>setMode(m.id)}>
            <div className="mode-icon">{m.id==="SHOWCASE"?"⚡":m.id==="QUICK"?"🎮":"🏰"}</div><div><b>{m.label}</b><span>{m.desc}</span></div>
          </button>)}
        </div>
        <div className="panel-heading difficulty-head"><div><div className="eyebrow">02 / THREAT LEVEL</div><h2>How intelligent is the crisis?</h2></div></div>
        <div className="difficulty-grid">
          {difficulties.map(x=><button key={x.id} className={`difficulty-card ${difficulty===x.id?"selected":""}`} onClick={()=>setDifficulty(x.id)} style={{"--accent":x.color}}>
            <div className="stars">{"★".repeat(x.stars)}<span>{"★".repeat(5-x.stars)}</span></div><b>{x.label}</b><small>{x.tagline}</small>
          </button>)}
        </div>
        <div className="launch-strip">
          <div><span>SELECTED</span><strong>{d.label.toUpperCase()}</strong><small>{d.tagline}</small></div>
          <button className="launch-btn" onClick={()=>startGame()} disabled={busy}>START CRISIS <ChevronRight/></button>
        </div>
      </section>
    </main>
  </Shell>
}

function FortressMap({compact=false, metrics={}}){
  return <div className={`fortress-map ${compact?"compact":""}`}>
    <div className="city-skyline"/>
    <div className="grid-floor"/>
    <div className="building b-hq"><div className="building-label">HQ</div><Building2/><span/></div>
    <div className="building b-ecm"><div className="building-label">ECM</div><Landmark/><span/></div>
    <div className="building b-trading"><div className="building-label">TRADING</div><TrendingUp/><span/></div>
    <div className="building b-risk"><div className="building-label">RISK</div><Shield/><span/></div>
    <div className="building b-treasury"><div className="building-label">TREASURY</div><Wallet/><span/></div>
    <div className="building b-compliance"><div className="building-label">COMPLIANCE</div><Scale/><span/></div>
    <div className="building b-intel"><div className="building-label">INTEL</div><Brain/><span/></div>
    <div className="road r1"/><div className="road r2"/>
    <div className="floating-market">NIFTY <b>{metrics.market ?? "-3.8%"}</b></div>
    <div className="agent-dot ad1"/><div className="agent-dot ad2"/><div className="agent-dot ad3"/>
  </div>
}

function Meter({label,value,icon:Icon, danger=false}){
  return <div className="meter"><div className="meter-label"><span><Icon size={14}/>{label}</span><b>{Math.round(value)}</b></div><div className="meter-track"><div className={`meter-fill ${danger?"danger":""}`} style={{width:`${Math.max(0,Math.min(100,value))}%`}}/></div></div>
}

function Game({game,decision,triggerCurveball,busy,onQuit}){
  const [showSwarm,setShowSwarm] = useState(true);
  if(!game) return null;
  const pct = Math.max(0,Math.min(100,game.integrity));
  return <Shell>
    <header className="topbar gamebar">
      <div className="brand"><div className="brand-mark">FC</div><div><div className="brand-name">FORTRESS CAPITAL</div><div className="brand-sub">{game.difficulty} • {game.mode}</div></div></div>
      <div className="game-timer"><Clock3 size={16}/><b>{formatTime(game.remaining_seconds)}</b></div>
      <button className="icon-btn" onClick={onQuit}><RotateCcw size={16}/> Exit</button>
    </header>
    <div className="game-layout">
      <aside className="left-rail">
        <div className="mission-card">
          <div className="eyebrow">ACTIVE SCENARIO</div>
          <h2>{game.scenario.title}</h2>
          <p>{game.scenario.brief}</p>
          <div className="threat-tag"><AlertTriangle size={13}/> {game.scenario.threat}</div>
        </div>
        <div className="integrity-card">
          <div className="integrity-head"><span>FORTRESS INTEGRITY</span><b>{Math.round(pct)}%</b></div>
          <div className="integrity-bar"><div style={{width:`${pct}%`}}/></div>
          <div className="integrity-state">{integrityLabel(pct)}</div>
        </div>
        <Meter label="Capital" value={game.metrics.capital} icon={Landmark}/>
        <Meter label="Liquidity" value={game.metrics.liquidity} icon={Wallet} danger={game.metrics.liquidity<35}/>
        <Meter label="Reputation" value={game.metrics.reputation} icon={Trophy}/>
        <Meter label="Client confidence" value={game.metrics.client} icon={Users}/>
        <Meter label="Regulatory" value={game.metrics.regulatory} icon={Scale}/>
        <button className="curveball-btn" onClick={triggerCurveball} disabled={busy || game.curveball_count>=game.max_curveballs}><Swords size={16}/> TRIGGER CURVEBALL</button>
      </aside>

      <main className="world-panel">
        <div className="world-header">
          <div><div className="eyebrow">LIVE COMMAND CENTER</div><h1>{game.event?.title || "FORTRESS UNDER WATCH"}</h1><p>{game.event?.message || "The swarm is monitoring the capital markets."}</p></div>
          <div className="crisis-meter"><span>CRISIS</span><div><div style={{width:`${game.crisis}%`}}/></div><b>{Math.round(game.crisis)}%</b></div>
        </div>
        <FortressMap metrics={{market:game.market_label}}/>
        <div className="decision-zone">
          <div className="decision-title"><span>COMMANDER DECISION</span><small>{game.decisions.length} options • consequences are live</small></div>
          <div className="decision-grid">
            {game.decisions.map(x=><button className="decision-card" key={x.id} onClick={()=>decision(x.id)} disabled={busy}>
              <div className="decision-icon">{x.icon}</div><div><b>{x.title}</b><span>{x.description}</span><small>Risk: {x.risk} • Reward: {x.reward}</small></div><ChevronRight/>
            </button>)}
          </div>
        </div>
      </main>

      <aside className={`swarm-panel ${showSwarm?"":"collapsed"}`}>
        <div className="swarm-head"><div><div className="eyebrow">MULTI-AGENT SWARM</div><h2>War Room</h2></div><button className="icon-btn" onClick={()=>setShowSwarm(!showSwarm)}>{showSwarm?"Hide":"Show"}</button></div>
        {showSwarm && <>
          <div className="consensus"><div><span>SWARM CONSENSUS</span><b>{game.consensus}%</b></div><div className="consensus-track"><div style={{width:`${game.consensus}%`}}/></div><small>{game.consensus>=75?"Aligned":"Agents disagree. Investigate."}</small></div>
          <div className="agent-list">
            {agents.map(a=>{
              const Icon=a.icon; const rec=game.agents?.[a.id] || {};
              return <div className={`agent ${rec.status||"stable"}`} key={a.id}><div className="agent-avatar"><Icon size={16}/></div><div className="agent-info"><b>{a.name}</b><span>{rec.message||"Monitoring..."}</span></div><div className="confidence">{rec.confidence||"--"}%</div></div>
            })}
          </div>
          <div className="combo-box"><div><Sparkles size={14}/> SWARM CHAIN</div><b>x{game.combo}</b><span>{game.combo>1?"Agents are collaborating effectively":"Make complementary decisions to build a chain."}</span></div>
        </>}
      </aside>
    </div>
    {toast && <div className="toast"><Zap size={16}/>{toast}</div>}
  </Shell>
}

function Result({game,onAgain,onHome}){
  const score=game.score;
  const result=game.result;
  return <Shell>
    <header className="topbar"><div className="brand"><div className="brand-mark">FC</div><div><div className="brand-name">FORTRESS CAPITAL</div><div className="brand-sub">COMMANDER REPORT</div></div></div></header>
    <main className="result-page">
      <div className="result-hero">
        <div className="result-icon">{result==="LEGENDARY"?"🏆":result==="VICTORY"?"🛡️":result==="PYRRHIC"?"⚠️":"💀"}</div>
        <div className="eyebrow">SCENARIO COMPLETE</div>
        <h1>{result==="LEGENDARY"?"FORTRESS SAVED":result==="VICTORY"?"STRATEGIC VICTORY":result==="PYRRHIC"?"PYRRHIC VICTORY":"FORTRESS FALLEN"}</h1>
        <div className="score-big">{score}<small>/ 1000</small></div>
        <p>{game.result_message}</p>
      </div>
      <div className="report-grid">
        <div className="report-card"><span>FINANCIAL PERFORMANCE</span><b>{game.report.financial}</b><div className="mini-bar"><i style={{width:`${game.report.financial}%`}}/></div></div>
        <div className="report-card"><span>SWARM UTILIZATION</span><b>{game.report.swarm}</b><div className="mini-bar"><i style={{width:`${game.report.swarm}%`}}/></div></div>
        <div className="report-card"><span>DECISION QUALITY</span><b>{game.report.decision}</b><div className="mini-bar"><i style={{width:`${game.report.decision}%`}}/></div></div>
        <div className="report-card"><span>RISK MANAGEMENT</span><b>{game.report.risk}</b><div className="mini-bar"><i style={{width:`${game.report.risk}%`}}/></div></div>
      </div>
      <div className="highlight-card"><div className="eyebrow">COMMANDER INSIGHT</div><h2>{game.insight}</h2><p>{game.insight_detail}</p></div>
      <div className="reward-strip"><div>🏆 <b>+{game.xp_earned} XP</b></div><div>🔥 SWARM CHAIN x{game.combo}</div><div>🎖 {game.achievement}</div></div>
      <div className="result-actions"><button className="primary-cta" onClick={onAgain}><RotateCcw/> RUN IT BACK</button><button className="ghost-cta" onClick={onHome}>RETURN TO FORTRESS</button></div>
    </main>
  </Shell>
}

function integrityLabel(v){ if(v>=80)return "FORTIFIED"; if(v>=60)return "STABLE"; if(v>=40)return "UNDER SIEGE"; if(v>=20)return "CRITICAL"; return "COLLAPSE IMMINENT"; }
function formatTime(s){s=Math.max(0,s); return `${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`}

createRoot(document.getElementById("root")).render(<App/>);
